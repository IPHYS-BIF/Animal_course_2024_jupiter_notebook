# Welcome to Advanced Course on Preclinical Imaging 2024

This is a small Jupyter book to introduce you an elementry data analysis.
The book will demonstrate some Python bascis and show how to process data acquired during 2-photon preclinical imaging.
For more informatoin visit [IPHYS Bioimaging facility web](https://bioimaging.fgu.cas.cz) or contact [Daniel Hadraba](mailto:daniel.hadraba@fgu.cas.cz).

Check out the content pages to see more.

```{tableofcontents}
```
